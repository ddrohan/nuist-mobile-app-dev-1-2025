
rootProject.name = "placemark-console"

