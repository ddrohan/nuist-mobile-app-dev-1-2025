import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    kotlin("jvm") version "1.7.0"
    application
    id("org.openjfx.javafxplugin") version "0.0.8"
}

javafx {
    // Declare the javafx modules we need to use
    modules("javafx.controls")
}

group = "org.setu.placemark"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(kotlin("test"))
    implementation("org.slf4j:slf4j-simple:1.7.36")
    implementation("io.github.microutils:kotlin-logging:2.1.23")
    implementation("com.google.code.gson:gson:2.9.0")
    implementation("no.tornado:tornadofx:1.7.20")
//    implementation("org.openjfx:javafx-base:18.0.1")
//    implementation("org.openjfx:javafx-controls:18.0.1")
//    implementation("org.openjfx:javafx-graphics:18.0.1")
}

tasks.test {
    useJUnitPlatform()
}

application {
    mainClassName = "org.setu.placemark.console.main.MainApp"
}

tasks.withType<KotlinCompile> {
    kotlinOptions.jvmTarget = "1.8"
}