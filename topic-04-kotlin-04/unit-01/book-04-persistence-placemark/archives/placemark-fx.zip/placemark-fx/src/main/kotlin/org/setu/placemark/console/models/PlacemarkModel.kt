package org.setu.placemark.console.models

data class PlacemarkModel(var id: Long? = 0,
                          var title: String = "",
                          var description: String = "")
