package org.setu.placemark.console.main

import org.setu.placemark.console.views.MenuScreen
import tornadofx.App

class MainApp : App(MenuScreen::class)